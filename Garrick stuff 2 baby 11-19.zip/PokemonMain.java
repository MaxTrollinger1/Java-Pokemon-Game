import java.util.*;
import java.math.*;
public class PokemonMain {
    public static void main(String[] args){
        Fire fireType = new Fire("Fire");//establish fire and water type to implement into moves and pokemon
        Water waterType = new Water("Water");
        Flamethrower flamethrower = new Flamethrower(70, 100, "Flamethrower", true, fireType);//establish the moves "Flamethrower" and "Hydro Pump" for pokemon objects
        HydroPump Hydro_pump = new HydroPump(130, 85, "Hydro Pump", true, waterType);
        Charmander charmander = new Charmander(20,20,20,20,20,20,fireType, flamethrower);
        Squirtle squirtle = new Squirtle(20,20,20,20,20,20,waterType, Hydro_pump);
        System.out.println(damageCalc(charmander.getAttack(), charmander.getSpecAttack(), squirtle.getDefense(), squirtle.getSpecDefense(), charmander.getMove1().getBasePower(), charmander.getMove1().getAccuracy(), charmander.getMove1().isSpecial(), squirtle.getWater().checkResistance(charmander.getMove1().getFireType().getType()), squirtle.getWater().checkWeakness(charmander.getMove1().getFireType().getType())));
        System.out.println(damageCalc(squirtle.getAttack(), squirtle.getSpecAttack(), charmander.getDefense(), charmander.getSpecDefense(), squirtle.getMove1().getBasePower(), squirtle.getMove1().getAccuracy(), squirtle.getMove1().isSpecial(), charmander.getFire().checkResistance(squirtle.getMove1().getWaterType().getType()), charmander.getFire().checkWeakness(squirtle.getMove1().getWaterType().getType())));
    }
    public static int damageCalc(int userAtt, int userSpecAtt, int oppDef, int oppSpecDef, int userBP, int userAcc, boolean isSpecial, boolean isRes, boolean isWeak){
        Random rand = new Random();
        int critRoll = rand.nextInt(100);//roll for if move is a critical hit
        int damRoll = rand.nextInt(16);//roll for damage (15 = 85% damage, 0 = 100% damage)
        int accRoll = rand.nextInt(100);//roll for if attack misses
        double critMult = 1.0;//set base crit multiplier
        double resMult = 1.0;
        double weakMult = 1.0;
        if (accRoll > userAcc){//if the accRoll is below the accuracy of the move, the move missed and does no damage
            System.out.println("The attack missed");
            return 0;
        }
        if (isRes){//if the "checkResistance()" function in the Types class file returns true, set the multiplier to .5
            System.out.println("The attack was not very effective...");
            resMult = .5;
        }
        if (isWeak){//if the "checkWeakness()" function in the Types class file returns true, set the multiplier to 2
            System.out.println("The attack was super effective!");
            weakMult = 2.0;
        }
        if (critRoll >95){//4% chance to change crit multiplier to 1.5
            System.out.println("Critical hit!");
            critMult = 1.5;
        }
        if (isSpecial){//if the attacking move is special (not physical), use this formula using the pokemon's special stats (this can be removed if we dont wanna do special stats
            double totalDam = (((22*userBP*(userSpecAtt/oppSpecDef))/50)+2)*critMult*((100-damRoll)*.01)*weakMult*resMult;
            int roundedDam = (int)Math.floor(totalDam);
            return roundedDam;
        }
        double totalDam = (((22*userBP*(userAtt/oppDef))/50)+2)*critMult*((100-damRoll)*.01)*weakMult*resMult;
        int roundedDam = (int)Math.floor(totalDam);
        return roundedDam;

    }
}
