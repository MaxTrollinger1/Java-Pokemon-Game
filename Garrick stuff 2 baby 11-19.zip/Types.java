import java.util.ArrayList;
import java.util.List;

public class Types {
    private String type;

    public Types(String type){
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
class Fire extends Types{
    List<String> weaknesses = new ArrayList<>();
    List<String> resistances = new ArrayList<>();

    public Fire(String type){
        super(type);
    }

    public boolean checkWeakness(String checkType){
        weaknesses.add("water");
        weaknesses.add("Water");
        if (weaknesses.contains(checkType)){
            return true;
        }
        return false;
    }
    public boolean checkResistance(String checkType){
        resistances.add("grass");
        resistances.add("Grass");
        if (resistances.contains(checkType)){
            return true;
        }
        return false;
    }
}
class Water extends Types{
    List<String> weaknesses = new ArrayList<>();
    List<String> resistances = new ArrayList<>();

    public Water(String type){
        super(type);
    }

    public boolean checkWeakness(String checkType){
        weaknesses.add("grass");
        weaknesses.add("Grass");
        if (weaknesses.contains(checkType)){
            return true;
        }
        return false;
    }
    public boolean checkResistance(String checkType){
        resistances.add("fire");
        resistances.add("Fire");
        if (resistances.contains(checkType)){
            return true;
        }
        return false;
    }
}
