public class Moves {
    private int basePower;
    private int Accuracy;
    private String moveName;
    private boolean isSpecial;


    public Moves(int basePower, int Accuracy, String moveName, boolean isSpecial){
        this.Accuracy = Accuracy;
        this.basePower = basePower;
        this.moveName = moveName;
        this.isSpecial = isSpecial;
    }

    public int getBasePower() {
        return basePower;
    }

    public int getAccuracy() {
        return Accuracy;
    }

    public String getMoveName() {
        return moveName;
    }

    public void setBasePower(int basePower) {
        this.basePower = basePower;
    }

    public void setAccuracy(int accuracy) {
        Accuracy = accuracy;
    }

    public void setMoveName(String moveName) {
        this.moveName = moveName;
    }

    public boolean isSpecial() {
        return isSpecial;
    }
    public Fire getFireType(){return null;}//put these functions here to overide in subclass (you can basically ignore these)
    public Water getWaterType(){return null;}
}
class Flamethrower extends Moves{
    private Fire fireType;

    public Flamethrower(int basePower, int Accuracy, String moveName, boolean isSpecial, Fire fireType){
        super(basePower, Accuracy, moveName, isSpecial);
        this.fireType = fireType;
    }
    @Override
    public Fire getFireType() {
        return fireType;
    }

    public void setFireType(Fire fireType) {
        this.fireType = fireType;
    }


}
class HydroPump extends Moves{
    private Water waterType;

    public HydroPump(int basePower, int Accuracy, String moveName, boolean isSpecial, Water waterType){
        super(basePower, Accuracy, moveName, isSpecial);
        this.waterType = waterType;
    }
    @Override
    public Water getWaterType() {
        return waterType;
    }

    public void setWaterType(Water waterType) {
        this.waterType = waterType;
    }


}